<?php
mysql_connect('localhost','root','');
mysql_select_db('donerinfo');
$sql="SELECT * FROM information";
$records=mysql_query($sql);
?>
