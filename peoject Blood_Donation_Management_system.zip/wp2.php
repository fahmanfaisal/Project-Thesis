
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>doner information</title>
	</br>
	<div class="header">
	   <legend><a href="#default" class="logo">Search Doner Information</a></legend> 
        <div class="header-right">
           <a href="home.php">Home</a>
		   <a href='wp2.php'>Donar Information</a>
		   <a href="contract.php">Contract</a>
			
			 
        </div>
    </div>
</head>

<style type="text/css">
    .header {
        overflow: hidden;
        padding: 5px 20px;
        background: blue;
        position: fixed;
        width: 50%;
    }

    .header a {
        float: left;
        color: black;
        color: white;
        padding: 12px;
        font-size: 18px;
        line-height: 25px;
		text-decoration: none;
        font-family: "Roboto Condensed";

    }

    .header a.logo {
        font-size: 45px;
        font-weight: bold;
        font-family: "Operator Mono";
    }

    .header-right {
        float: right;
    }



</style>
 

<html>

<body>



 <form action='wp2.php' method='post'>
 
    <table  height='400px' width='600px' align='center'> 
	
    

<table align='center' border='1px' >
<tr>
	<td>Name</td>
	<td>Contact</td>
	<td>Address</td>
	<td>Blood Group</td>
	</tr>
	
	<?php
	$db=mysqli_connect("localhost","root","","donerinfo");
	$sql="SELECT * FROM informtion";

        

?>

<?php
     $conn=mysqli_connect("localhost","root","","donerinfo");
	 $query="SELECT *FROM information";
	 
	 $result=$conn->query($query);
	 
	 if($result->num_rows>0)
	 {
			while($row=$result->fetch_assoc())
			{
				if($row["name"]!=""){
				echo "<tr><td>";
				echo $row["name"];
				echo "</td>";
				echo "<td>";
				echo $row["contract"];
				echo "</td>";
				echo "<td>";
				echo $row["address"];
				echo "</td>";
				
				echo "<td>";
				echo $row["bloodgroup"];
				echo "</td>";
				echo "</tr>";
				}
				
			}
	 }
	 echo "</table>";
?>
	
	<tr>
	</tr>
	
	
		
	
</table>

</form>
</table>

<form action="result.php"  method="post" >
		<input type="text" size ="25" name="user_query"   placeholder='BloodGroup' />
        
		<input type="submit" name="search" value="search" />
	</form>
</body>

</html>