<html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Home Page</title>
	</br>
	<div class="header">
	   <legend><a href="#default" class="logo">Blood Donation Management System</a></legend> 
        <div class="header-right">
           <a href="home.php">Home</a>
		   <a href='wp2.php'>Donar Information</a>
		   <a href="contract.php">Contact</a>
			
			 
        </div>
    </div>
</head>

<style type="text/css">
    .header {
        overflow: hidden;
        padding: 5px 20px;
        background: green;
        position: fixed;
        width: 50%;
    }

    .header a {
        float: left;
        color: black;
        color: white;
        padding: 12px;
        font-size: 18px;
        line-height: 25px;
		text-decoration: none;
        font-family: "Roboto Condensed";

    }

    .header a.logo {
        font-size: 45px;
        font-weight: bold;
        font-family: "Operator Mono";
    }

    .header-right {
        float: right;
    }



</style>
<body>
    </br>
	</br>
	</br>
	
	<table height='400px' width='800px' align='center' >
	</br>
	</br>
	</br>
	<tr>
	 <td><fieldset>
	<b> Blood Donation System</b>
	 
    <b><i><p>Hi welcome to my Blood Donation Management System web page.Here you can register as an donar with give your proper information & by this others can search those information about that particular person.</p></b></i>	 
	</td>
	
	 </fieldset>
	 </tr>
	 <tr>
			<td><strong><i>Not Register yet?</i></strong></td>
	       
            <td>
			<input type="button" /> <a href="wp1.php"><strong>Register</strong></a> 
			 
			 
           
	        </tr>
	 
	</table>

</body>
</html>
