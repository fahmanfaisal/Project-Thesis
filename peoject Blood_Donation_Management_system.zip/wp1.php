<?php 
if (isset ($_POST ["submit"])){
	if (empty($_POST["name"])) 
	{
		$name = "Name is required.";
	}
	// if name with unusual letter or number.
	else if (!preg_match ("/^[a-zA-Z .-]*$/",$_POST["name"]))
	{
		$name = "Only Valid Name is Required";
	}


if($_REQUEST['name']!=""){
//Session_start();
$db=mysqli_connect("localhost","root","","donerinfo");
if($db->connect_error)
	echo "error";

if(isset($_POST['submit'])){
	$name=mysqli_real_escape_string($db,$_POST['name']);
	$contract=mysqli_real_escape_string($db,$_POST['contract']);
	$address=mysqli_real_escape_string($db,$_POST['address']);
	$bloodgroup=mysqli_real_escape_string($db,$_POST['bloodgroup']);
	
	$sql="insert into information(name,contract,address,bloodgroup)
	values('$name','$contract','$address','$bloodgroup')";
	
	if($db->query($sql))
		echo "Success";

        }
}
}


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Home Page</title>
	</br>
	<div class="header">
	   <legend><a href="#default" class="logo">Add Doner Information</a></legend> 
        <div class="header-right">
           <a href="home.php">Home</a>
		   <a href="contract.php">contact</a>
			
			 
        </div>
    </div>
</head>

<style type="text/css">
    .header {
        overflow: hidden;
        padding: 5px 20px;
        background: red;
        position: fixed;
        width: 50%;
    }

    .header a {
        float: left;
        color: black;
        color: white;
        padding: 12px;
        font-size: 18px;
        line-height: 25px;
		text-decoration: none;
        font-family: "Roboto Condensed";

    }

    .header a.logo {
        font-size: 45px;
        font-weight: bold;
        font-family: "Operator Mono";
    }

    .header-right {
        float: right;
    }



</style>
 
 <body>
    
    <form action='wp1.php' method='post' >
	<table height='400px' width='600px'  align='center'>
	<tr> 
	
	</tr>
	
	</fieldset>
	<tr>
				<td>
					<strong>Name</strong>
				</td>
                <td>				
				
					<input type="text" size ="25" name="name"   placeholder='Name of the doner' >
					<?php
							if(isset($name))echo $name;
				    ?>
					
				</td>
				
	</tr>
	
	
	<tr>
				<td>
					<strong>Contract No</strong>
                </td>
                <td colspan='3'>				
				
					<input type="text" name='contract'   size ="25"  placeholder='Enter the phone number(+880)' >
				</td>
				<td></td>
				
	</tr>
	<tr>
				<td >
					<strong>Address</strong>  <!--password feild-->
				</td>
				<td colspan="3">
					<input type="text"  size ="25" name="address"  placeholder='Enter your full address' /> <!--taking input type as password.-->
				</td>
				<td></td>

			</tr>
	
	<tr>
				<td>
					<strong>Blood Group</strong></br>
					
					<select name='bloodgroup' >
			<option>O+</option>
			<option>O-</option>
			<option selected='selected'>A+</option>
			<option>A-</option>
			<option>B+</option>
			<option>B-</option>
	        <option>AB+</option>
            <option>AB-</option>
			</select>
				</td>
				
	</tr>
	 
	
	
	<tr>
	
				<td colspan="3" align="left">
			
				<input type="submit" name="submit" value="submit" />
				</td>
				<td>
				<input type='Reset'  />
				</td>
				
    </tr>

	
 </table>
 </body>
</html>