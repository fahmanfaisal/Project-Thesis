<html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Home Page</title>
	</br>
	<div class="header">
	   <legend><a href="#default" class="logo">Blood Donation Management System</a></legend> 
        <div class="header-right">
           <a href="home.php">Home</a>
		   <a href='wp2.php'>Donar Information</a>
		   <a href="contract.php">Contact</a>
			
			 
        </div>
    </div>
</head>

<style type="text/css">
    .header {
        overflow: hidden;
        padding: 5px 20px;
        background: green;
        position: fixed;
        width: 50%;
    }

    .header a {
        float: left;
        color: black;
        color: white;
        padding: 12px;
        font-size: 18px;
        line-height: 25px;
		text-decoration: none;
        font-family: "Roboto Condensed";

    }

    .header a.logo {
        font-size: 45px;
        font-weight: bold;
        font-family: "Operator Mono";
    }

    .header-right {
        float: right;
    }



</style>
<body>
    </br>
	</br>
	</br>
	
	<table height='400px' width='800px' align='center'   >
	</br>
	</br>
	</br>
<div id="main" class="form">
<div id="Message_area" class="form"> 
	<tr>
	 <td>
	 </div>
<form method="post"> 


<input type = "text" name = "name"  style ="width:350px;height:50px;" placeholder="Donar name" />	
</br>
<input type = "text" name = "mgs"  style ="width:350px;height:50px;" placeholder="Type your messege" />	
</br>		
<input type ="submit" name = "submit" style ="height:50px;" value = "Submit" >

<button type="button"
onclick="document.getElementById('demo').innerHTML = Date()">
Click me to display Date and Time.</button>
<p id="demo"></p>

	 
	</td>
	
	 
	 
	</table>

</body>
</html>
