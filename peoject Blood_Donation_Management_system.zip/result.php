<?php

	if(isset($_POST["search"]))
	{
     $conn=mysqli_connect("localhost","root","","donerinfo");
	 $user_keyword=$_REQUEST['user_query'];
	 $query="SELECT *FROM information where bloodgroup like'%$user_keyword%'";
	 
	 $result=$conn->query($query);
	 echo "<table align='center' border='1px black'>";
	 echo "<tr><th>Name</th><th>Contact</th><th>Address</th><th>Blood Group</th></tr>";
	 if($result->num_rows>0)
	 {
			while($row=$result->fetch_assoc())
			{
				if($row["name"]!=""){
				echo "<tr><td>";
				echo $row["name"];
				echo "</td>";
				echo "<td>";
				echo $row["contract"];
				echo "</td>";
				echo "<td>";
				echo $row["address"];
				echo "</td>";
				
				echo "<td>";
				echo $row["bloodgroup"];
				echo "</td>";
				echo "</tr>";
				}
				
			}
	 }
	 echo "</table>";
	}
?>